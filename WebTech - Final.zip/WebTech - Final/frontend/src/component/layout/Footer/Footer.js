import React from "react";
import "./Footer.css";

const Footer = () => {
  return (
    <footer id="footer">


      <div className="midFooter">
        <h1>Art Hub</h1>
      </div>

      
    </footer>
  );
};

export default Footer;
