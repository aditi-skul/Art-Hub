import React, { Fragment, useEffect } from "react";
import "./Home.css";
import MetaData from "../layout/MetaData";
import ProductCard from "./ProductCard";
import { getProduct } from "../../actions/productAction";
import { useSelector, useDispatch } from 'react-redux';
import { useAlert } from 'react-alert';
import Loader from "../layout/Loader/Loader";
const product = {
  name:"Blue Shirt",
  images: [{url: "https://media.istockphoto.com/id/653991092/photo/navy-blue-t-shirt-on-hanger.jpg?s=612x612&w=0&k=20&c=prEnJvMncvQ4ONJfDh8GdyU4OlkmTDoxFg9gR00-v6w="}],
  price:"3000",
  _id:"Aditi",

}

const Home = () => {
  const alert = useAlert();
  const dispatch = useDispatch();
  const { loading, error, products, productCount } = useSelector(
    (state) => state.products
  );
  
  useEffect(() => {
    
    dispatch(getProduct());
  }, [dispatch, error, alert]);
  return (
    <Fragment>
      {loading ? (
        <Loader />
      ) : 
        <Fragment>
          <MetaData title="Art Hub" />

          <div className="banner">
            <p>Welcome to Art Hub</p>
            <h1>Find beautiful pieces for your homes!</h1>

            <a href="#container">
              <button>
                Scroll 
              </button>
            </a>
          </div>

          <h2 className="homeHeading">Featured Products</h2>

          <div className="container" id="container">
            {products &&
              products.map((product) => (
                <ProductCard key={product._id} product={product} />
              ))}
          </div>

        </Fragment>
      }
    </Fragment>
  );
    };

export default Home;
