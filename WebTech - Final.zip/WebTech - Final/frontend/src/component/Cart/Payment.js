import React, { useState } from "react";
import QRCode from "qrcode.react";

import { useNavigate } from "react-router-dom";
import { createOrder } from "../../actions/orderAction";
import { useDispatch, useSelector } from "react-redux";
import "./payment.css";


const QrCodeComponent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { shippingInfo, cartItems } = useSelector((state) => state.cart);
  
  const orderInfo = JSON.parse(sessionStorage.getItem("orderInfo"));
  const [status, setStatus] = useState(null);

  const order = {
    shippingInfo,
    orderItems: cartItems,
    itemsPrice: orderInfo.subtotal,
    taxPrice: orderInfo.tax,
    shippingPrice: orderInfo.shippingCharges,
    totalPrice: orderInfo.totalPrice,
  };

  const handleDone = () => {
    setStatus("done");
    dispatch(createOrder(order));
    navigate("/success");
  };

  const handleFailed = () => {
    setStatus("failed, try again please.");
  };

  return (
    <div style={{ textAlign: "center" }}>
      <QRCode value="https://example.com" />
      <div>
        <button onClick={handleDone}>Done</button>
        <button onClick={handleFailed}>Failed</button>
      </div>
      {status && <p>Status: {status}</p>}
    </div>
  );
};

export default QrCodeComponent;
